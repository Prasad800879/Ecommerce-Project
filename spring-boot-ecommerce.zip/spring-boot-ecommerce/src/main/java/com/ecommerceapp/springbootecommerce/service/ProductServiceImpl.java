package com.ecommerceapp.springbootecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ecommerceapp.springbootecommerce.model.Product;
import com.ecommerceapp.springbootecommerce.model.ProductCategory;
import com.ecommerceapp.springbootecommerce.repository.ProductCategoryRepository;
import com.ecommerceapp.springbootecommerce.repository.ProductRepository;



@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductRepository pRepo;
	
	@Autowired
	ProductCategoryRepository pCatRepo;

	@Override
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return pRepo.findAll();
	}
	
	@Override
	public Product findById(Long id) {
		Optional<Product> pOpt = pRepo.findById(id);
		Product product = new Product(); 
		if(pOpt.isPresent())
		{
			product = pOpt.get();
		}
		return product;
	}

	@Override
	public Page<Product> findByCategoryId(int category_id, Pageable pageable) {
		// TODO Auto-generated method stub
		return pRepo.findByCategoryId(category_id, pageable);
	}

	@Override
	public List<ProductCategory> findAllCategory() {
		// TODO Auto-generated method stub
		return pCatRepo.findAll();
	}

	@Override
	public Page<Product> findByNameContaining(String name, Pageable pageable) {
		// TODO Auto-generated method stub
		return pRepo.findByNameContaining(name, pageable);
	}

	
	
}
