package com.ecommerceapp.springbootecommerce.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.ecommerceapp.springbootecommerce.model.Product;
import com.ecommerceapp.springbootecommerce.model.ProductCategory;



public interface ProductService {

	public List<Product> findAll();
	
	public Product findById(Long id);
	
	public Page<Product> findByCategoryId(int category_id,Pageable pageable);
	
	public List<ProductCategory> findAllCategory();
	
	public Page<Product> findByNameContaining(String name,Pageable pageable);
	
}
