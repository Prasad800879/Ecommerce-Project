package com.ecommerceapp.springbootecommerce.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ecommerceapp.springbootecommerce.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

	@Query(value="select U from Product U where U.category_id=?1")
	public Page<Product> findByCategoryId(int category_id,Pageable pageable);
	
	public Page<Product> findByNameContaining(String name,Pageable pageable);
	
}