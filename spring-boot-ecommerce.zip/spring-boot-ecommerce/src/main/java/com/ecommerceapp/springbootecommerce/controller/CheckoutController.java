package com.ecommerceapp.springbootecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerceapp.springbootecommerce.dto.Purchase;
import com.ecommerceapp.springbootecommerce.dto.PurchaseResponse;
import com.ecommerceapp.springbootecommerce.service.CheckoutService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/checkout")
public class CheckoutController {
	
	@Autowired
	private CheckoutService checkoutService;
	
	@PostMapping(value="/purchase",produces = "application/json")
	public PurchaseResponse placeOrder(@RequestBody Purchase purchase) {
		
		PurchaseResponse purchaseResponse = checkoutService.placeOrder(purchase);
		
		return purchaseResponse;
	}

}
