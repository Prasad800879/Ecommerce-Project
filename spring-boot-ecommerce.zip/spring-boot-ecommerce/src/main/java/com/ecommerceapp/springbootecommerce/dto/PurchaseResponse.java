package com.ecommerceapp.springbootecommerce.dto;

import org.springframework.stereotype.Component;

@Component
public class PurchaseResponse {

    private String orderTrackingNumber;

	public String getOrderTrackingNumber() {
		return orderTrackingNumber;
	}

	public void setOrderTrackingNumber(String orderTrackingNumber) {
		this.orderTrackingNumber = orderTrackingNumber;
	}
    
}
