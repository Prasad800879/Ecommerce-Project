package com.ecommerceapp.springbootecommerce.service;

import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerceapp.springbootecommerce.dto.Purchase;
import com.ecommerceapp.springbootecommerce.dto.PurchaseResponse;
import com.ecommerceapp.springbootecommerce.model.Customer;
import com.ecommerceapp.springbootecommerce.model.Order;
import com.ecommerceapp.springbootecommerce.model.OrderItem;
import com.ecommerceapp.springbootecommerce.repository.CustomerRepository;

@Service
public class CheckoutServiceImpl implements CheckoutService{
	
	@Autowired
	public CustomerRepository customerRepository;
	
	@Autowired
	public PurchaseResponse purchaseResponse;


	@Override
	public PurchaseResponse placeOrder(Purchase purchase) {
		// TODO Auto-generated method stub
		// retrieve the order info from dto
        Order order = purchase.getOrder();

        // generate tracking number
        String orderTrackingNumber = generateOrderTrackingNumber();
        order.setOrderTrackingNumber(orderTrackingNumber);

        // populate order with orderItems
        Set<OrderItem> orderItems = purchase.getOrderItems();
        orderItems.forEach(item -> order.add(item));

        // populate customer with order
        Customer customer = purchase.getCustomer();
        customer.add(order);

        // save to the database
        customerRepository.save(customer);
        
        purchaseResponse.setOrderTrackingNumber(orderTrackingNumber);
        // return a response
        return purchaseResponse;
	}


	private String generateOrderTrackingNumber() {
		// TODO Auto-generated method stub
		return UUID.randomUUID().toString();
	}

}
