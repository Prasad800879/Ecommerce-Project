package com.ecommerceapp.springbootecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerceapp.springbootecommerce.model.Product;
import com.ecommerceapp.springbootecommerce.model.ProductCategory;
import com.ecommerceapp.springbootecommerce.service.ProductService;



@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ProductController {

	@Autowired
	ProductService pService;
	
	@GetMapping("/allProducts")
	public List<Product> findAll(){
		return pService.findAll();
	}
	
	
	@GetMapping("/product/{id}")
	public Product findById(@PathVariable Long id)
	{
		return pService.findById(id);
	}
	
	@GetMapping("/products/findByCategoryId")
	public Page<Product> findCategoryById(@RequestParam int id,Pageable pageable){
		return pService.findByCategoryId(id, pageable);
	}
	
	@GetMapping("/allCategories")
	public List<ProductCategory> findAllCategory()
	{
		return pService.findAllCategory();
	}
	
	@GetMapping("/search/{name}")
	public Page<Product> findByNameContaining(@PathVariable String name,Pageable pageable)
	{
		return pService.findByNameContaining(name, pageable);
	}
}
